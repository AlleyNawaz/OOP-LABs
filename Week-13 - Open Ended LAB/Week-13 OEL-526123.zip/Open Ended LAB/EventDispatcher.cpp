#include "EventDispatcher.h"

void EventDispatcher::registerUnit(HospitalUnit* unit) {
    units.push_back(unit);
}

void EventDispatcher::dispatch(const HospitalEvent &e) {
    cout << "DISPATCHING: " << e << endl;
    
    for (HospitalUnit* unit : units) {
        unit->respond(e);
    }
}